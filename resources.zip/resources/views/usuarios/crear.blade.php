@extends('layouts.app')

@section('js')
	<script src="{{asset('js/validaciones/Ciudades.js')}}"></script>
	<script src="{{asset('js/validaciones/Oficinas.js')}}"></script>
	<script src="{{asset('js/validaciones/Usuarios.js')}}"></script>
@endsection

@section('content')
	<div class="col-md-12 col-md-offset-0">
		
		<h2>Usuarios</h2>
		
		
		<ul class="nav nav-tabs">
			<li class="nav-item">
				<a class="nav-link" href="{{url('usuarios')}}">Lista de Usuarios</a>
			</li>
			<li class="nav-item">
				<a class="nav-link active">Crear Usuario</a>
			</li>
		</ul>
		<br />
		<h4>Crear Usuarios</h4>
		
		<div class="panel panel-default">
			<div class="panel-heading">Crear Usuarios</div>
			<div class="panel-body">
				<form method="POST" action="{{url('usuarios/store')}}">
					{{ csrf_field() }}
					<div class="form-row">
						<div class="form-group">
							<label for="name">Nombre</label>
							<input type="text" class="form-control" name="name" id="name" placeholder="Nombre" value="{{ old('name') }}" required>
						</div>
						<div class="form-group col-md-6">
							<label for="email">Email</label>
							<input type="email" class="form-control" name="email" id="email" placeholder="Email" required>
						</div>
					</div>
					<div class="form-row">
						<div class="form-group col-md-6">
							<label for="passwd">Password</label>
							<input type="password" class="form-control" name="passwd" id="passwd" placeholder="Password" required>
						</div>
						<div class="form-group col-md-6">
							<label for="clave">Repetir Password</label>
							<input type="password" class="form-control" name="clave" id="clave" placeholder="clave" required>
						</div>
					</div>
					<div class="form-row">
						<div class="form-group col-md-6">
							<label for="rol">Rol</label>
							<select class="form-control" name="rol" id="rol" required>
								<option value="">-Seleccione-</option>
								@foreach($roles as $rol)
									<option value="{{$rol->id}}">{{$rol->rol}}</option>
								@endforeach
							</select>
						</div>
						<div class="form-group col-md-6">
							<label for="rol">Departamento</label>
							<select class="form-control" name="depto" id="depto">
								<option value="">-Seleccione-</option>
								@foreach($dptos as $depto)
					 				<option value="{{$depto->id}}">{{$depto->departamento}}</option>
								@endforeach
							</select>
						</div>
					</div>
					<div class="form-row">
						<div class="form-group col-md-6">
							<label for="ciudad">Ciudad</label>
							<select class="form-control" name="ciudad" id="ciudad">
								<option value="">-Seleccione-</option>								
							</select>
						</div>
						<div class="form-group col-md-6">
							<label for="oficina">Oficina</label>
							<select class="form-control" name="oficina" id="oficina" required>
								<option value="">-Seleccione-</option>	
								@foreach($oficinas as $oficina)
									<option value="{{$oficina->id}}">{{$oficina->oficina}}</option>
								@endforeach							
							</select>
						</div>
					</div>
					
					<button type="submit" class="btn btn-primary">Guardar</button>
				</form>
			</div>
		</div>
	</div>

@endsection
